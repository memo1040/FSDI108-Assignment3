from flask import Flask, abort, render_template
from mock_data import mock_data
import json

app = Flask(__name__)


me = {
    "name": "Guillermo",
    "last": "Monge",
    "age": 32,
    "hobbies": [],
    "email": "gmt1040@gmail.com",
    "address": {
        "street": "Delta",
        "city": "San Diego"
    }
}


@app.route("/")
@app.route("/home")
def home():
    return render_template("index.html")

@app.route("/test")
def simple_test():
    return "Hello there!"


@app.route("/about")
def about():
    return render_template("about.html")

@app.route("/about/email")
def email():
    return me["email"]

@app.route("/about/address")
def address():
    return me["address"]["street"] + ", " + me["address"]["city"]



###########################################
############## API Methods
###########################################


@app.route("/api/catalog")
def get_catalog():
    #returns the catalog as JSON string
    return json.dumps(mock_data)

## /api/categories
# return the list (string) of UNIQUE categories

@app.route("/api/categories")
def get_categories():
    categories = []
    for prod in mock_data:
        if not prod["category"] in categories:
            categories.append(prod["category"])
    
    return json.dumps(categories)


@app.route("/api/product/<id>")
def get_product(id):
    for prod in mock_data:
        if prod["_id"] == id:
            return prod
          
    return abort(404) # 404 = Not Found


@app.route("/api/catalog/<category>")
def get_by_category(category):
    result = []
    for prod in mock_data:
        if prod["category"].lower() == category.lower():
            result.append(prod)

    return json.dumps(result)


@app.route("/api/cheapest")
def get_cheapest():
    pivot = mock_data[0]
    for prod in mock_data: 
        if prod["price"] < pivot["price"]:
            prod = pivot

    return pivot

# /api/cheapest
# cheapest product

# start the server
# debug true will restart the server automatically
app.run(debug=True)




# /about